var mysql = require('mysql'); //importação do mysql;
var connection = mysql.createConnection(
    {
        host: 'localhost',
        user: 'ifms',
        password: 'ifms',
        database: 'portal_noticias'
    }); //Criação da conexão com o banco de dados;
